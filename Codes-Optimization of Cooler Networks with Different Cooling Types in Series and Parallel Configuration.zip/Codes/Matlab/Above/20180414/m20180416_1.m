syms Tx Ty;
Tin=70; Tout=45;

for Tx = Tout:1:Tin
    for Ty = Tout:1:Tx
        [x,f] = Cooling(Tx,Ty,7.091360359,70,45,9.4,46.3,60,3.23,0.9999,0.306,0.763,30428,35928,19922);
    end
end


x
f
