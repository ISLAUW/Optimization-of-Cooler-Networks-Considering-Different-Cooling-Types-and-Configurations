clc;clear;

% ��������ѡ�ͣ�DAC/SAC����������
Arm=[7.09 2.33 7.02 6.98 7.12 5.64 4.73 16.54 2.27 4.81 7.97 2.33]; % ������������ kg/s
ArT1=[70.00 131.10 99.60 113.53 80.00 132.52 87.50 87.77 140.00 92.50 80.11 80.00]; % ������������¶� ��
ArT2=[45.00 55.00 45.00 50.00 45.00 120.00 45.00 60.00 60.00 70.00 50.00 60.00]; % ������������¶� ��
ArTx=zeros(1,12);
ArQ1=zeros(1,12);
ArV1=zeros(1,12);
ArP1=zeros(1,12);
ArI1=zeros(1,12);
ArQ3=zeros(1,12);
ArP3=zeros(1,12);
ArI3=zeros(1,12);
ArW3=zeros(1,12);
ArC1=zeros(1,12);
ArC3=zeros(1,12);
ArC=zeros(1,12);

n=188; 
Df=2.4;
tw=20; % �����¶� ��

C11=0;C33=0;Cz=0;

for i=1:12
    for Tx = ArT2(i):1:ArT1(i)
        m=Arm(i);
        ArTx(i)=Tx;
        T1=ArT1(i);
        T2=ArT2(i);
        
        [Q1,V1,P1,I1]=designDAC(m,T1,Tx,n,Df);

        [Q3,P3,W3,I3]=designCWS (m,Tx,T2,tw);
        
        C1=8000*0.06*P1+I1/10; 
        C3=8000*0.06*P3+10*Q3*I3/10;
        C=C1+C3;
        C0=10^6;
       
        if C<C0
            C0=C;
            C11=C1;
            C33=C3;
            Cz=C;
        end
              

               
    end
        ArQ1(i)=Q1;
        ArV1(i)=V1;
        ArP1(i)=P1;
        ArI1(i)=I1;
        ArQ3(i)=Q3;
        ArP3(i)=P3;
        ArI3(i)=I3;
        ArW3(i)=W3;
        ArC1(i)=C11;
        ArC3(i)=C33;
        ArC(i)=Cz;
        
        
end

disp (ArTx);

disp (ArP1);
disp (ArP3);
disp (ArW3);

disp (ArC1);
disp (ArC3);  
disp (ArC);
        
