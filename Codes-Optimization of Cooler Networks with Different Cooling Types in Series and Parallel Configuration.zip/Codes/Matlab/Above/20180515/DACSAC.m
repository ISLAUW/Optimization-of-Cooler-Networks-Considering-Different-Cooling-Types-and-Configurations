% ��������ѡ�ͣ�DAC/SAC����������
Arm=[7.09 2.33 7.02 6.98 7.12 5.64 4.73 16.54 2.27 4.81 7.97 2.33]; % ������������ kg/s
ArT1=[70.00 131.10 99.60 113.53 80.00 132.52 87.50 87.77 140.00 92.50 80.11 80.00]; % ������������¶� ��
ArT2=[45.00 55.00 45.00 50.00 45.00 120.00 45.00 60.00 60.00 70.00 50.00 60.00]; % ������������¶� ��
ArTx=zeros(1,12);
ArQ1=zeros(1,12);
ArP1=zeros(1,12);
ArI1=zeros(1,12);
ArQ2=zeros(1,12);
ArP2=zeros(1,12);
ArI2=zeros(1,12);
ArW2=zeros(1,12);
ArC1=zeros(1,12);
ArC2=zeros(1,12);
ArC=zeros(1,12);

n=188; 
Df=2.4;

for i=1:12
    Tx=ArTx(i);
    for Tx = ArT2(i):0.1:ArT1(i)
        m=Arm(i);
        T1=ArT1(i);
        T2=ArT2(i);
        [Q1,P1,I1]=designDAC(m,T1,Tx,n,Df);
        ArQ1(i)=Q1;
        ArP1(i)=P1;
        ArI1(i)=I1;
        [Q2,P2,I2,W2]=designSAC (m,Tx,T2,n,Df);
        ArQ2(i)=Q2;
        ArP2(i)=P2;
        ArI2(i)=I2;
        ArW2(i)=W2;
        
        C1=8000*0.06*P1; 
        C2=8000*0.06*P2+8000*(3600*W2/(2*10^(-5)*20^3-0.0059*20^2+0.0191*20+999.9))*0.5531;
        C=C1+C2;
        C0=10^6;
        if C<C0
            C0=C;
            %C11=C1;
            %C22=C2;
            Cz=C;
        end
              
        ArC1(i)=C1;
        ArC2(i)=C2;
        ArC(i)=Cz;
               
    end
end

disp (ArP1);
disp (ArP2);
disp (ArW2);
disp (ArC1);
disp (ArC2);
disp (ArC);
        
