clc;
clear;

m=7.09;T1=70;T2=45;n=188;Df=2.4;
%m=2.33;T1=131.1;T2=55;n=188;Df=2.4;

[Q2,P2,I2,W2]= designSAC (m,T1,T2,n,Df);

Q2
P2
I2
W2
