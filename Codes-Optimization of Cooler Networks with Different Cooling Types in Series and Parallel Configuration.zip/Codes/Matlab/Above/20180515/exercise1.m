clc;
clear;

m=7.09;T1=70;T2=45;n=188;Df=2.4;
%m=2.33;T1=131.1;T2=55;n=188;Df=2.4;

[K,t2,Q1,P1,I1]= designDAC (m,T1,T2,n,Df);

K
t2
Q1
P1
I1
