clc;clear;

m=7.09;
T1=70;
T2=45;
Tx=57.5;

n=188; Df=2.4;tw=20;

[Q1,V1,P1,I1]=designDAC(m,T1,Tx,n,Df);

[Q3,P3,W3,I3]=designCWS (m,Tx,T2,tw);

C1=8000*0.06*P1+I1/10;

C3=8000*0.06*P3+10*Q3*I3/10;

V1
P1
I1
C1

P3
W3
I3

C3

P=P1+P3
W=3600*W3/(2*10^(-5)*24^3-0.0059*24^2+0.0191*24+999.9) % m3/h
C=C1+C3
