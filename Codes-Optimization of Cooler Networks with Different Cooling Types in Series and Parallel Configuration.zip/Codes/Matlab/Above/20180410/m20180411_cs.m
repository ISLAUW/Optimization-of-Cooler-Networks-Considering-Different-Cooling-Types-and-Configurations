A=10000000000;

for i=1:10
    N(i)=100*rand(1)
end

  


if C<A
    A=C;
    Cz=C;
end
Cz
